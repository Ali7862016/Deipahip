# Dropship Auto
Run: `npm install && npm start` then open http://localhost:3000
Flow: supplier sync (15 min) -> pricing rules -> live products -> paid order -> auto supplier order (10 sec) -> tracking.
Next: swap MockSupplier for a real supplier API, add Stripe/Shopify webhook to POST /api/orders, add auth.

## Deploy on Render
1. Push this folder to a GitHub repo. 2. Render > New > Blueprint > pick the repo.
3. Set ADMIN_PASSWORD when prompted. Login: user `admin`.
4. Checkout/webhooks POST to /api/orders with header `x-api-key: <ORDER_KEY>` (shown in Render env vars).
Note: the persistent disk needs a paid Render plan (starter).
